from models import GradeReport

DATA = [
    {"name": "Alice", "score": 78},
    {"name": "Bob", "score": 55},
    {"name": "Cara", "score": 92},
    {"name": "Dan", "score": 61},
    {"name": "Eve", "score": 47},
]

if __name__ == "__main__":
    report = GradeReport(DATA)
    print(report.summary(pass_threshold=60))