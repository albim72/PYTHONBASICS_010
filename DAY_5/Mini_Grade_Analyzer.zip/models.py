from typing import List, Dict
from functions import average, passed

class GradeReport:
    """OOP wrapper using functional helpers."""

    def __init__(self, data: List[Dict]):
        self.data = data

    def summary(self, pass_threshold: int = 60) -> str:
        avg = average(self.data)
        passing = passed(self.data, pass_threshold)

        lines = [
            f"Total students: {len(self.data)}",
            f"Average score: {avg:.2f}",
            f"Passed (>= {pass_threshold}): {len(passing)}",
        ]

        top = sorted(self.data, key=lambda r: r['score'], reverse=True)[:3]
        lines.append("Top 3 students:")
        for row in top:
            lines.append(f" - {row['name']}: {row['score']}")

        return "\n".join(lines)