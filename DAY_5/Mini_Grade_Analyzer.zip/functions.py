from typing import List, Dict

def get_scores(data: List[Dict]) -> List[int]:
    """Return a list of all scores."""
    return list(map(lambda row: row["score"], data))

def average(data: List[Dict]) -> float:
    """Compute average score."""
    scores = get_scores(data)
    return sum(scores) / len(scores) if scores else 0.0

def passed(data: List[Dict], threshold: int) -> List[Dict]:
    """Filter students who passed (score >= threshold)."""
    return list(filter(lambda row: row["score"] >= threshold, data))